<?php

namespace Abraham\TwitterOAuth;

/**
 * @author Abraham Williams <abraham@abrah.am>
 */
class TwitterOAuthException extends \Exception
{
}
