# README #
Twitter PHP API 

Examples-twitter-php-api.php
- Send tweets
- send private messages
- get followers
- get friends
- search users by words and follow
- auto follow yours followers

Files:
+ Examples-twitter-php-api.php
+ index.php
+ OAuth.php
+ twitteroauth.php
+ README

Orginal readme and repo
https://github.com/pedroventura/pv-auto-tweets

Orginal autor page: 
http://www.webinfopedia.com/auto-tweet-with-oauth-in-php.html

Have a nice day
[Strony internetowe fxstar.eu](https://fxstar.eu)
